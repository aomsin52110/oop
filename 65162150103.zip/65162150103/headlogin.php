<?php include "head.php" ?>
<<div class="header">
      <div class="main">
        <div class="title">
        Member ZONE
        </div>
        <ul class="menuber">
           
        <p style="font-size: 14px;">สวัสดี<?php echo $_SESSION['lname']?></p>
          
          <li style="font-size: 14px;"><a href="logout.php?logout=1">logout</a></li>
          
        </ul>
      </div>
    </div>