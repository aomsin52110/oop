<?php 
include "headuser.php"
?>

<?php
                    if (!empty($row["img"])) {

                    ?>

                    <?php }?>

<?php 
include "foot.php"
?>